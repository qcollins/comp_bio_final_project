python setup.py sdist --formats=gztar,zip upload
