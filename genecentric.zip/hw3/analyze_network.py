from pprint import pprint
from operator import itemgetter
import sys



def main(): 

    method = None

    # usage code
    if len(sys.argv) > 1:
        if sys.argv[1] == "majority-vote":
            print("using majority-vote")
            method = majority_vote
        elif sys.argv[1] == "rank2-vote":
            print("using rank2-vote")
            method = rank2_vote
        else: 
            print("Usage: invalid flag")
            exit()
    else: 
        print("Usage: needs majority-vote or rank2-vote as second flag")
        exit()

    # Default file names
    edges_fname =  "confidence.ppi" #  "edges.dat" #
    categories_fname =  "MIPSFirstLevel.anno3" # "categories.dat" #  


    if len(sys.argv) >= 4:
        edges_fname = sys.argv[2]
        categories_fname = sys.argv[3]
    
    print("using " + edges_fname + " and " + categories_fname)

    # build data structures
    (adj_matrix, entry_lookup) = build_graph_from_file(edges_fname)
    annotations = build_annotations_from_file(categories_fname)

    # run validation algorithm
    success_rate = validate_leave_one_out(method, adj_matrix, 
                                          entry_lookup, annotations)

    print("success rate: " + str(success_rate))


########################################################################
#                         Validation Code                              #
########################################################################

# returns percentage of correct guesses of method
def validate_leave_one_out(method, adj_matrix, entry_lookup, annotations):
    matches_found = 0
    # make a guess for every entry in graph  
    for name in entry_lookup:
        guesses = method(name, adj_matrix, 
                         entry_lookup, annotations, 
                         count=1)
        # if one of the guesses matches one of actual annotations 
        if set(guesses).intersection(annotations[name]):
            matches_found += 1
    return float(matches_found)/len(entry_lookup)


 
###########################################################################
#                      Code for Prediction Algorithms                     #
###########################################################################


# take the top count guesses from rank2_vote all
def rank2_vote(target_key, adj_matrix, entry_lookup, annotations, count=1):
    all = rank2_vote_all(target_key, adj_matrix, entry_lookup, annotations)
    return all[:count]

# generate sorted list of annotated guesses for target_key using rank2 vote
#   best guess is first
def rank2_vote_all(target_key, adj_matrix, entry_lookup, annotations):
    potential_annotations = {}
    target_index = entry_lookup[target_key]
    # iterate through all entries in the graph
    for (name, i) in entry_lookup.items():
        # ignore entries that are the target or that are unconnected
        if target_index != i and adj_matrix[target_index][i] > 0.0 :
            # loop over annotations associated with each adjacent node
            cur_annotations = annotations[name]
            for annotation in cur_annotations:
                # add weight connection^2 to the weight of that annotation
                if annotation in potential_annotations:
                    potential_annotations[annotation] += \
                        adj_matrix[target_index][i] ** 2
                else:
                    potential_annotations[annotation] =  \
                        adj_matrix[target_index][i] ** 2
    # sort the annotations so highest rated annotaions are first

    sorted_annotations = sorted(potential_annotations.items(), 
                         key=itemgetter(1), reverse = True)
    return list(map(itemgetter(0), sorted_annotations))


# take top count guesses from majority vote all
def majority_vote(target_key, adj_matrix, entry_lookup, annotations, count=1):
    all = majority_vote_all(target_key, adj_matrix, entry_lookup, annotations)
    return all[:count]

# generate sorted list of annotated guesses for target_key using majority vote
#   best guess is first
def majority_vote_all(target_key, adj_matrix, entry_lookup, annotations):
    potential_annotations = {}
    target_index = entry_lookup[target_key]
    for (name, i) in entry_lookup.items():
        if adj_matrix[target_index][i] != 0.0 and target_index != i:
            cur_annotations = annotations[name]
            for annotation in cur_annotations:
                if annotation in potential_annotations:
                    potential_annotations[annotation]+= 1
                else:
                    potential_annotations[annotation] = 1

    # sort the annotations so highest rated annotaions are first
    sorted_annotations = sorted(potential_annotations.items(),
                                key=itemgetter(1), reverse = True)
    return list(map(itemgetter(0), sorted_annotations))
###################################################################
#              Functions to Build Data Structures                 #
###################################################################

# returns annotations dictionary from annotations file name
def build_annotations_from_file(fname):
    raw_lines = [line.rstrip('\n') for line in open(fname)]
    split_lines = [raw.split('\t') for raw in raw_lines]

    return build_annotations(split_lines)

# returns annotations dictionary from list of split line
#   each line in split lines is array, with first element being character
def build_annotations(split_lines):
    annotations_dict = {}
    for line in split_lines:
        name = line[0]
        annotations = line[1:]
        annotations_dict[name] = annotations
    return annotations_dict


# returns adjcency matrix and entry lookup dictionary from file name
def build_graph_from_file(fname):
    raw_edges    = [line.rstrip('\n') for line in open(fname)]
    parsed_edges = [ (start, end, float(strength)) for [start, end, strength] 
                        in [line.split('\t') for line in raw_edges]]


    return build_graph(parsed_edges)

# builds graph and lookup dictionary from parsed edges
# parsed edges is list of tuples (start, end, strength)
#   when start and end are nodes and strength is the weight of their edge
def build_graph(parsed_edges):
    lookup = {}

    # build lookup
    next_index = 0

    for (start, end, strength) in parsed_edges:
        if start not in lookup:
            lookup[start] = next_index
            next_index += 1

        if end not in lookup:
            lookup[end] = next_index
            next_index += 1        


    num_elements = len(lookup)
    adj_matrix = [[0.0 for i in range(num_elements)] for j in range(num_elements)]
    for (start, end, strength) in parsed_edges:
        adj_matrix[lookup[start]][lookup[end]] = strength
        adj_matrix[lookup[end]][lookup[start]] = strength

    return (adj_matrix, lookup)
        


# run main after definitions
main()