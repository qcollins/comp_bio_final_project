<?php require_once('includes/header.php'); ?>

<h3>Downloads</h3>

<p><strong>NOTE:</strong> We have not built a version for Windows yet, but if
   you have some Python experience, you may be able to get it running from
   our <a href="https://github.com/BurntSushi/genecentric">github
   repository</a>.</p>

<h4>Version 1.0.3</h4>

<ul>
  <li><a href="download_linux.php">Download for Linux/Mac</a></li>
  <li><a href="download_win.php">Download for Windows</a></li>
</ul>
  

<?php require_once('includes/footer.php'); ?>

