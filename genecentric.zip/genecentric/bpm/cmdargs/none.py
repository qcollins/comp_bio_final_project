import bpm

class __Config:
    geneinter = None
    bpm = None
    verbose = None

conf = __Config

# Set the global conf variable
bpm.conf = conf

